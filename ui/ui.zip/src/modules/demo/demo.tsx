import React from 'react'
import CategoryPreviews from './library/CategoryPreviews'
import ProductLists from './library/ProductLists'

const Demo = async () => {
  return (
    <div>
      <ProductLists />
      {/* <CategoryPreviews /> */}
    </div>
  )
}

export default Demo
