import React from 'react'
import FormLogin from './library/FormLogin'

const Login = async () => {
  return <FormLogin />
}

export default Login
