import React from 'react'
import ChangePasswordForm from './library/ChangePasswordForm'

const Change = () => {
  return <ChangePasswordForm />
}

export default Change
