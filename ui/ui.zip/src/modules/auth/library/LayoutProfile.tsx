import React from 'react'

const LayoutProfile = ({ children }) => {
  return <div>{children}</div>
}

export default LayoutProfile
