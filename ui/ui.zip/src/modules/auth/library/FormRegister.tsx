const FormRegister = () => {
  return (
    <div>
      hello Form Register
    </div>
  )
}

export default FormRegister
