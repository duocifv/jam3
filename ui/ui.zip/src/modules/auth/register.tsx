"use client"
import React from 'react'
import RegisterForm from './library/RegisterForm'

const RegisterPage = () => {
  return (
    <div>
      <RegisterForm />
    </div>
  )
}

export default RegisterPage
