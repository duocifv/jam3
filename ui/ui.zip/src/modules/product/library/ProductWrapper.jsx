import React from 'react'

const ProductWrapper = async ({ children }) => {
  return <div>{children}</div>
}

export default ProductWrapper
