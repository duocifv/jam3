
const LayoutPost = ({ children }) => {
  return children
}

export default LayoutPost
