import data from '../content/data.json'

export const useKeyBox = () => {
  return data
}
