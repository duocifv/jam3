
import Demo from '@/modules/demo/demo'
import React from 'react'

const DemoPage = () => {
  return (
    <Demo />
  )
}

export default DemoPage
