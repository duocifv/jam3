"use client"
import React from 'react'
import RegisterPage from '@/modules/auth/register'

const page = () => {
  return (
    <div>
      Hello Register Page
      <RegisterPage />
    </div>
  )
}

export default page
