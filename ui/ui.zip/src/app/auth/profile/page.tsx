import Profile from '@/modules/auth/profile'
import React from 'react'

const ProfilePage = () => {
  return <Profile />
}

export default ProfilePage
