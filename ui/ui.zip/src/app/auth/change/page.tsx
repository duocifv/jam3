import Change from '@/modules/auth/change'
import React from 'react'

const ChangePage = () => {
  return <Change />
}

export default ChangePage
