import ForgotPage from '@/modules/auth/forgot'
import React from 'react'

const Forgot = async () => <ForgotPage />

export default Forgot
