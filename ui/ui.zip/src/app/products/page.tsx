import React from 'react'
import Product from '@/modules/product/product'

const ProductPage = async () => {
  return <Product />
}

export default ProductPage
