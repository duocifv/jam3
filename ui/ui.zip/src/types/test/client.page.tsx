// 'use client'
// import React from 'react'

// const titleColorClasses = {
//   blue: 'from-blue-400 to-blue-600 dark:from-blue-300 dark:to-blue-500',
//   teal: 'from-teal-400 to-teal-600 dark:from-teal-300 dark:to-teal-500',
// }

// interface ClientPostProps {
//   post: {
//     name: string
//     body: string
//   }
// }

// const PostsClientPage = (props: ClientPostProps) => {
//   const { post } = props
//   return (
//     <div>
//       {post.name && (
//         <div
//           className={`bg-clip-text text-transparent bg-gradient-to-r ${
//             titleColorClasses['blue']
//           }`}
//         >
//           <h3>{post.name}</h3>
//         </div>
//       )}
//       {post.body && (
//         <div>
//           <p>{post.body}</p>
//         </div>
//       )}
//     </div>
//   )
// }

// export default PostsClientPage
